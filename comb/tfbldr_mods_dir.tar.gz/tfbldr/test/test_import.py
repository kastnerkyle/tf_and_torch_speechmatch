import logging
logging.getLogger('tensorflow').disabled = True

# implicit test
from tfbldr import *

def test_import_all():
    pass
