from .plot import get_viridis
from .plot import autoaspect
from .audio import specgram
from .audio import specplot
